<template>
    <div class="Home">
      <h3>Logged in</h3>
      <div id="feedbackDiv"></div>
    <div>
        <button class="button1" @click="charge">Charge</button>
        </div>
      <div>
        <button class="button1" @click="index">Log out</button>
        </div>
    </div>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {};
  },
  methods: {
    index() {
      this.$router.push({ name: "Index" });
    },
    charge() {
      this.$router.push({ name: "Charge" });
    }
  }
};
</script>