<template>
    <div class="StartChargePage">
      <h3>Start Charging</h3>
      <div id="feedbackDiv"></div>
    <div>
        <button class="button1" @click="charge">Back</button>
        </div>
    </div>
</template>

<script>
export default {
  name: "StartCharge",
  data() {
    return {};
  },
  methods: {
    charge() {
      this.$router.push({ name: "Charge" });
    }
  }
};
</script>